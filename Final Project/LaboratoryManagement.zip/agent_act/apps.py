from __future__ import unicode_literals

from django.apps import AppConfig


class AgentActConfig(AppConfig):
    name = 'agent_act'
